import React from 'react'

function DashBoard() {
  return (
    <div>DashBoard</div>
  )
}

export default DashBoard